module purge
module load conda3/202402
conda activate /hpcf/authorized_apps/proteomics_apps/conda/proteoda2
### NO imputation by Gtest
Rscript proteoDA_diann.NoAvg_per_contrasts_gtest.R "$diann_output" > >(tee proteoDA_stdout.log) 2> >(tee proteoDA_stderr.log >&2)
## run Gtest imputation and add control proteins to volcano plot
#Rscript proteoDA_diann_per_contrasts_gtest_ctrlProteins.R "$diann_output" > >(tee proteoDA_stdout.log) 2> >(tee proteoDA_stderr.log >&2)
wait
Rscript GenerateReports.R
wait
conda deactivate
